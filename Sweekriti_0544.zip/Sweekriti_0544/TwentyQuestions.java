import java.util.Scanner;
public class TwentyQuestions
{
    private static Scanner sc= new Scanner(System.in);
    public static void main(String[ ] args)
    {
        BTNode<String> root;

        instruct( );
        root = beginningTree( );
        do {
            play(root);
        } while (query("Do you wish to play again?"));

        System.out.println("Thanks for teaching me a thing or two.");
        root.print(1);
    }

    public static void instruct( )
    {
        System.out.println("Please think of a mammal.");
        System.out.println("I will ask some yes/no questions to try to figure out which animal you're thinking of.");
    }


    public static void play(BTNode<String> current)
    {
        while (!current.isLeaf( ))
        {
            if (query(current.getData( )))
                current = current.getLeft( );
            else
                current = current.getRight( );
        }

        System.out.print("My guess is " + current.getData( ) + ". ");
        if (!query("Am I right?"))
            learn(current);
        else
            System.out.println("I knew that :)");
    }

    public static BTNode<String> beginningTree( )
    {
        BTNode<String> root;
        BTNode<String> child;
        BTNode<String> child1;
        BTNode<String> child2=null;
        BTNode<String> child3=null;
        BTNode<String> child4=null;
        BTNode<String> child5=null;
        BTNode<String> child6=null;
        BTNode<String> child7=null;
        BTNode<String> child8=null;
        BTNode<String> child9=null;
        BTNode<String> child10=null;
        BTNode<String> child11=null;
        BTNode<String> child12=null;
        BTNode<String> child13=null;
        BTNode<String> child14=null;

        //Questions to ask to the user
        final String ROOT_QUESTION = "Is it a mammal?";
        final String LEFT_QUESTION = "Is it able to move on land?";
        final String LEFT_QUESTION2 = "Is it a solitary animal?";
        final String RIGHT_QUESTION2 = "Is it larger than a truck?";
        final String RIGHT_QUESTION3 = "Does it have tusks?";
        final String RIGHT_QUESTION = "Does it have any limbs/tentacles?";
        final String LEFT_QUESTION4 = "Does it have more than four limbs/tentacles?";
        final String LEFT_QUESTION5 = "Does it have an exoskeleton?";
        final String LEFT_QUESTION6 = "Does it have claws?";
        final String LEFT_QUESTION7 = "Does it have a long tail?";
        final String RIGHT_QUESTION7 = "Does it have 8 arms?";
        final String RIGHT_QUESTION5 = "Does it have a shell?";
        final String RIGHT_QUESTION4 = "Can it sting?";
        final String LEFT_QUESTION8 = "Is it long and snakelike?";
        final String RIGHT_QUESTION8 = "Is it generally smaller than a car?";
        final String ANIMAL1 = "Seal";
        final String ANIMAL2 = "Sea Lion";
        final String ANIMAL3 = "Walrus";
        final String ANIMAL4 = "Whale";
        final String ANIMAL5 = "Dolphin";
        final String ANIMAL6 = "Shrimp";
        final String ANIMAL7 = "Lobster";
        final String ANIMAL8 = "Crab";
        final String ANIMAL9 = "Jellyfish";
        final String ANIMAL10 = "Octopus";
        final String ANIMAL11 = "Squid";
        final String ANIMAL12 = "Turtle";
        final String ANIMAL13 = "Alligator";
        final String ANIMAL14 = "Eel";
        final String ANIMAL15 = "Stingray";
        final String ANIMAL16 = "Shark";
        final String ANIMAL17 = "Fish";

        // Create the root node with the question “Are you a mammal?”
        root = new BTNode<String>(ROOT_QUESTION, null, null);

        //Create and attach the left subtree
       child = new BTNode<String>(LEFT_QUESTION, child2 ,child14);
        root.setLeft(child);

        child2 = new BTNode<String>(LEFT_QUESTION2,null,child3);
        child2.setLeft(new BTNode<String>(ANIMAL1, null, null));
        child.setLeft(child2);

        //Create and attach the right subtree
        child14 = new BTNode<String>(RIGHT_QUESTION2,null,null);
        child14.setLeft(new BTNode<String>(ANIMAL4,null,null));
       child14.setRight(new BTNode<String>(ANIMAL5,null,null));
        child.setRight(child14);

        child3 = new BTNode<String>(RIGHT_QUESTION3, null, null);
        child3.setLeft(new BTNode<String>(ANIMAL3, null, null));
        child3.setRight(new BTNode<String>(ANIMAL2, null, null));
         child.setRight(child3);

        child1 = new BTNode<String>(RIGHT_QUESTION, child4, child8);
        root.setRight(child1);

        child4 = new BTNode<String>(LEFT_QUESTION4,child5,child10);
        child1.setLeft(child4);

        child5 = new BTNode<String>(LEFT_QUESTION5,child6,child8);
        child4.setLeft(child5);

        child6 = new BTNode<String>(LEFT_QUESTION6,child7, null);
        child6.setRight(new BTNode<String>(ANIMAL6,null,null));
        child5.setLeft(child6);

        child7 = new BTNode<String>(LEFT_QUESTION7, null, null);
        child7.setLeft(new BTNode<String>(ANIMAL7,null,null));
        child7.setRight(new BTNode<String>(ANIMAL8,null,null));
        child6.setLeft(child7);

        child8 = new BTNode<String>(RIGHT_QUESTION4,null,child9);
        child8.setLeft(new BTNode<String>(ANIMAL9,null,null));
        child5.setRight(child8);

       child9 = new BTNode<String>(RIGHT_QUESTION7,null,null);
        child9.setLeft(new BTNode<String>(ANIMAL10,null,null));
        child9.setRight(new BTNode<String>(ANIMAL11,null,null));
        child8.setRight(child9);

        child10 = new BTNode<String>(RIGHT_QUESTION5,null,null);
        child10.setLeft(new BTNode<String>(ANIMAL12,null,null));
        child10.setRight(new BTNode<String>(ANIMAL13,null,null));
        child4.setRight(child10);

        child11 = new BTNode<String>(RIGHT_QUESTION4,child12,child13);
        child1.setRight(child11);

        child12 = new BTNode<String>(LEFT_QUESTION8,null,null);
        child12.setLeft(new BTNode<String>(ANIMAL14,null,null));
        child12.setRight(new BTNode<String>(ANIMAL15,null,null));
        child11.setLeft(child12);

        child13 = new BTNode<String>(RIGHT_QUESTION8,null,null);
        child13.setLeft(new BTNode<String>(ANIMAL17,null,null));
        child13.setRight(new BTNode<String>(ANIMAL16,null,null));
        child11.setRight(child13);

        return root;
    }


    public static void learn(BTNode<String> current)

    {
        String guessAnimal;   // The animal that was just guessed
        String correctAnimal; // The animal that the user was thinking of
        String newQuestion;   // A question to distinguish the two animals

        // Set Strings for the guessed animal, correct animal and a new question.
        guessAnimal = current.getData( );
        System.out.println("I give up. What are you? ");
        correctAnimal = sc.nextLine( );
        System.out.println("Please type a yes/no question that will distinguish a");
        System.out.println(correctAnimal + " from a " + guessAnimal + ".");
        newQuestion = sc.nextLine( );

        // Put the new question in the current node, and add two new children.
        current.setData(newQuestion);
        System.out.println("As a " + correctAnimal + ", " + newQuestion);
        if (query("Please answer"))
        {
            current.setLeft(new BTNode<String>(correctAnimal, null, null));
            current.setRight(new BTNode<String>(guessAnimal, null, null));
        }
        else
        {
            current.setLeft(new BTNode<String>(guessAnimal, null, null));
            current.setRight(new BTNode<String>(correctAnimal, null, null));
        }
    }

    public static boolean query(String prompt)
    {
        String answer;

        System.out.print(prompt + " [Y or N]: ");
        answer = sc.nextLine( ).toUpperCase( );
        while (!answer.startsWith("Y") && !answer.startsWith("N"))
        {
            System.out.print("Invalid response. Please type Y or N: ");
            answer = sc.nextLine( ).toUpperCase( );
        }

        return answer.startsWith("Y");
    }

}